
<template>
    <div style="width: 100vw; padding: 0;">
      {{ recipes }}
      <button @click="getRecipes">Get Recipes</button>
    </div>
</template>

<script>
</script>